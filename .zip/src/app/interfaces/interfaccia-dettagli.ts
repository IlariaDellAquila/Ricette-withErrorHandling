export interface InterfacciaDettagli {
    id?:string,
    descrizione?:string,
    difficolta?: number,
    img?:string ,
    imgs?:[],
    ingredienti?:Ingrediente[],
}
interface Ingrediente{
    descrizione?:string, 
    quantita?:string,
    _id?:string
}