export interface InterfaceRicette {
    _id:string,
    descrizione:string, 
    difficolta:number,
    img:string,
}
