import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceRicetteService {

  constructor( private _http : HttpClient) { }

  getAllRicette(){
    return this._http.get('https://pumpkin-pie-18472.herokuapp.com/all')
  }

  getDettagliRicette(id:string){
    return this._http.get('https://pumpkin-pie-18472.herokuapp.com/' + id)
  }

  deleteRicette(id:string){
    return this._http.delete('https://pumpkin-pie-18472.herokuapp.com/' + id)
  }
}
