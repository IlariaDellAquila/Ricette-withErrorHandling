import { Component } from '@angular/core';
import { InterfacciaDettagli } from './interfaces/interfaccia-dettagli';
import { InterfaceRicette } from './interfaces/interface-ricette';
import { ServiceRicetteService } from './services/service-ricette.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Ricette';
  ricette: InterfaceRicette[] = [];
  dettaglio: InterfacciaDettagli = {};

  constructor(private _service: ServiceRicetteService){}

  ngOnInit(): void {
   this._service.getAllRicette().subscribe((data:any)=> {
    this.ricette = data;
    
   })
  }

  showModal: boolean = false;

  showDetail(id:string | any){
   this.showModal=true;
   this._service.getDettagliRicette(id).subscribe((data:any) => {
     this.dettaglio = data;
   })
  }

  deleteRicetta(id:string | any){
  this._service.deleteRicette(id).subscribe((data:any) => {
    this.ricette = this.ricette.filter(data => data._id !== id);
  })
  }

}
