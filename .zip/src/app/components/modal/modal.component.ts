import { Component, Input, OnInit } from '@angular/core';
import { InterfacciaDettagli } from 'src/app/interfaces/interfaccia-dettagli';
import { ServiceRicetteService } from 'src/app/services/service-ricette.service';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  @Input ('ricetta') ricetta : InterfacciaDettagli = {};
  @Input ('showModal') showModal : boolean = false;

  constructor(private _service: ServiceRicetteService) { }

  ngOnInit(): void {
  }

}
